import { getWords, removeWord, restoreWord, removeWords, restoreWords, onWordsChanged, toCsv, sourceUrl, sourceKey, groupBySource } from '../lib/words.js';
import { renderWordList, renderPager, showToast, matches } from '../lib/wordlist-view.js';
import { languageName } from '../lib/languages.js';
import { loadSettings, onSettingsChanged, hotkeyLabel } from '../lib/settings.js';

// The full word list: a side menu of the PDFs and pages words were saved from,
// beside one page of words at a time. The chosen source is kept in the address
// (#source=…), so the reader's "Open full list" can link straight to a PDF's words.

const PAGE_SIZE = 25;
const $ = (id) => document.getElementById(id);
let words = await getWords();
let settings = await loadSettings();
let query = '';
let language = '';
let source = sourceFromHash(); // a source key (see sourceKey), or '' for every word
let page = 1;

function sourceFromHash() {
  const m = location.hash.match(/^#source=(.+)$/);
  return m ? decodeURIComponent(m[1]) : '';
}

const svg = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const ICONS = {
  all: svg('<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/>'),
  pdf: svg('<path d="M14 3.5H7.2a1.7 1.7 0 0 0-1.7 1.7v13.6a1.7 1.7 0 0 0 1.7 1.7h9.6a1.7 1.7 0 0 0 1.7-1.7V8z"/><path d="M14 3.5V8h4.5M9 13h6M9 16.5h4"/>'),
  web: svg('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.4 2.3 3.6 5.2 3.6 8.5s-1.2 6.2-3.6 8.5c-2.4-2.3-3.6-5.2-3.6-8.5s1.2-6.2 3.6-8.5z"/>'),
  copied: svg('<rect x="5.5" y="4.5" width="13" height="16" rx="1.6"/><path d="M9.5 4.5v-.7a.8.8 0 0 1 .8-.8h3.4a.8.8 0 0 1 .8.8v.7M9 10h6M9 13.5h6M9 17h4"/>'),
};
const TYPE_NAME = { pdf: 'PDF', web: 'web page', copied: 'words copied in Chrome’s viewer' };
const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
const day = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : '');
const host = (url) => {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
};
const where = (group) => (group.type === 'web' ? host(group.url) || 'Web page' : group.type === 'copied' ? 'Copied in Chrome’s viewer' : group.url?.startsWith('file:') ? 'PDF on this computer' : 'PDF');

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function choose(key) {
  source = key;
  page = 1;
  history.replaceState(null, '', key ? `#source=${encodeURIComponent(key)}` : location.pathname + location.search);
  resetDelete();
  render();
}

// ------------------------------------------------------------------ side menu

function renderSources(groups) {
  const item = (key, title, meta, count, type) => {
    const button = el('button', 'source');
    button.type = 'button';
    button.title = title;
    button.setAttribute('aria-current', String(key === source));
    button.innerHTML = ICONS[type];
    const text = el('span', 'source__text');
    text.append(el('span', 'source__title', title), el('span', 'source__meta', meta));
    button.append(text, el('span', 'source__count', String(count)));
    button.addEventListener('click', () => choose(key));
    const li = el('li');
    li.append(button);
    return li;
  };
  $('sources').replaceChildren(
    item('', 'All words', groups.length ? `From ${plural(groups.length, 'source')}` : 'Nothing saved yet', words.length, 'all'),
    ...groups.map((g) => item(g.key, g.title, `${where(g)} · ${day(g.latest)}`, g.words.length, g.type)),
  );
  // Keep the chosen one in sight when the menu scrolls (many sources, or a narrow window)
  const menu = $('sources').closest('.sources');
  const chosen = $('sources').querySelector('[aria-current="true"]');
  if (chosen && menu.scrollHeight > menu.clientHeight) {
    const box = menu.getBoundingClientRect();
    const at = chosen.getBoundingClientRect();
    if (at.top < box.top || at.bottom > box.bottom) menu.scrollTop += at.top - box.top - 12;
  }
}

// ------------------------------------------------------------------- the list

function render() {
  const groups = groupBySource(words);
  if (source && !groups.some((g) => g.key === source)) source = ''; // its last word was deleted
  const group = groups.find((g) => g.key === source) ?? null;
  renderSources(groups);

  $('summary').textContent = words.length
    ? `${plural(words.length, 'saved word')} from ${groups.length === 1 ? 'one PDF or page' : `${groups.length} PDFs and pages`}.`
    : `No saved words yet. Select a word in a PDF or on a web page and press ${hotkeyLabel(settings.saveHotkey)} to save it.`;

  $('viewTitle').textContent = group ? group.title : 'All words';
  $('viewMeta').textContent = group
    ? `${where(group)} · ${plural(group.words.length, 'word')} · last saved ${day(group.latest)}`
    : words.length
      ? 'Newest first. Choose a PDF or page on the left to see only its words.'
      : '';
  $('openSource').hidden = !group?.url;
  $('openSource').textContent = group?.type === 'web' ? 'Open page' : 'Open PDF';
  $('deleteSource').hidden = !group;
  if ($('deleteSource').dataset.confirm !== 'true') $('deleteSource').textContent = 'Delete all';

  const scoped = group ? group.words : words;
  const langs = [...new Set(scoped.map((w) => w.source).filter(Boolean))];
  if (!langs.includes(language)) language = '';
  const select = $('language');
  select.replaceChildren(new Option('All languages', ''), ...langs.map((l) => new Option(languageName(l), l)));
  select.value = language;
  select.hidden = langs.length < 2;

  const list = scoped.filter((w) => !language || w.source === language);
  const total = list.filter((w) => matches(w, query)).length;
  page = Math.min(page, Math.max(1, Math.ceil(total / PAGE_SIZE)));
  renderWordList($('list'), list, {
    query,
    page,
    pageSize: PAGE_SIZE,
    showSource: !group,
    empty: 'Words you save while reading will show up here.',
    onOpen: (w) => window.open(sourceUrl(w), '_blank'),
    onDelete: async (w) => {
      await removeWord(w.id);
      showToast(`Deleted "${w.word}"`, { action: 'Undo', onAction: () => restoreWord(w) });
    },
  });
  renderPager($('pager'), {
    page,
    pageSize: PAGE_SIZE,
    total,
    onPage: (to) => {
      page = to;
      render();
      $('viewTitle').scrollIntoView({ block: 'nearest' });
    },
  });
  $('export').disabled = !total;
}

// ------------------------------------------------------------------- actions

$('openSource').addEventListener('click', () => {
  const group = groupBySource(words).find((g) => g.key === source);
  if (!group?.url) return;
  const url = group.type === 'web' ? group.url : `${new URL('../viewer/viewer.html', location.href).href}?file=${encodeURIComponent(group.url)}`;
  window.open(url, '_blank');
});

// Deleting a whole source takes two clicks, then can still be undone.
let confirmTimer = 0;
function resetDelete() {
  clearTimeout(confirmTimer);
  const button = $('deleteSource');
  delete button.dataset.confirm;
  button.textContent = 'Delete all';
}
$('deleteSource').addEventListener('blur', resetDelete);
$('deleteSource').addEventListener('click', async () => {
  const button = $('deleteSource');
  const group = groupBySource(words).find((g) => g.key === source);
  if (!group) return;
  if (button.dataset.confirm !== 'true') {
    button.dataset.confirm = 'true';
    button.textContent = `Delete ${plural(group.words.length, 'word')}?`;
    clearTimeout(confirmTimer);
    confirmTimer = setTimeout(resetDelete, 4000);
    return;
  }
  resetDelete();
  const removed = await removeWords(group.words.map((w) => w.id));
  showToast(`Deleted ${plural(removed.length, 'word')} from “${group.title.length > 40 ? `${group.title.slice(0, 39)}…` : group.title}”`, {
    action: 'Undo',
    duration: 8000,
    onAction: async () => {
      await restoreWords(removed);
      choose(group.key);
    },
  });
});

$('search').addEventListener('input', (e) => {
  query = e.target.value.trim();
  page = 1;
  render();
});
$('language').addEventListener('change', (e) => {
  language = e.target.value;
  page = 1;
  render();
});
$('export').addEventListener('click', () => {
  const shown = words.filter((w) => (!source || sourceKey(w) === source) && (!language || w.source === language) && matches(w, query));
  const group = groupBySource(words).find((g) => g.key === source);
  const slug = group ? `-${group.title.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '').slice(0, 40)}` : '';
  const blob = new Blob(['﻿' + toCsv(shown)], { type: 'text/csv;charset=utf-8' });
  const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: `leggio-words${slug}-${new Date().toISOString().slice(0, 10)}.csv` });
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
});
addEventListener('hashchange', () => {
  source = sourceFromHash();
  page = 1;
  render();
});
onSettingsChanged((patch) => {
  settings = { ...settings, ...patch };
  render();
});
onWordsChanged((next) => {
  words = next;
  render();
});
render();
