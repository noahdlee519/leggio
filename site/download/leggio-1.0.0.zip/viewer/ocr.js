import Tesseract from '../vendor/tesseract/tesseract.esm.min.js';

const TESSERACT_DIR = new URL('../vendor/tesseract/', import.meta.url).href;

const STATUS_LABELS = {
  'loading tesseract core': 'Starting OCR',
  'initializing tesseract': 'Starting OCR',
  'initialized tesseract': 'Starting OCR',
  'loading language traineddata': 'Downloading language data',
  'loading language traineddata (from cache)': 'Loading language data',
  'initializing api': 'Starting OCR',
  'initialized api': 'Starting OCR',
  'recognizing text': 'Reading text',
};

/**
 * One Tesseract worker, created on first use. Jobs run one at a time.
 * Code is bundled with the extension; language data (a few MB per language)
 * is downloaded from jsDelivr on first use and cached in IndexedDB by Tesseract.
 */
export class OcrEngine {
  #worker = null;
  #langs = '';
  #chain = Promise.resolve();
  #onProgress = null;

  recognize(image, langs, onProgress) {
    const job = this.#chain.then(async () => {
      this.#onProgress = onProgress;
      try {
        const worker = await this.#ensureWorker(langs);
        const { data } = await worker.recognize(image, {}, { text: false, blocks: true });
        return data;
      } finally {
        this.#onProgress = null;
      }
    });
    this.#chain = job.catch(() => {});
    return job;
  }

  async #ensureWorker(langs) {
    const key = langs.join('+');
    if (!this.#worker) {
      this.#langs = key;
      this.#worker = Tesseract.createWorker(langs, Tesseract.OEM.LSTM_ONLY, {
        workerPath: `${TESSERACT_DIR}worker.min.js`,
        corePath: `${TESSERACT_DIR}core/`,
        workerBlobURL: false,
        logger: (m) => this.#log(m),
        errorHandler: (err) => console.warn('[ocr]', err),
      });
      this.#worker.catch(() => (this.#worker = null));
    } else if (this.#langs !== key) {
      const worker = await this.#worker;
      await worker.reinitialize(langs, Tesseract.OEM.LSTM_ONLY);
      this.#langs = key;
    }
    return this.#worker;
  }

  #log({ status, progress }) {
    this.#onProgress?.({ label: STATUS_LABELS[status] ?? 'Reading text', progress: progress ?? 0 });
  }
}

/**
 * Flattens Tesseract's blocks → paragraphs → lines → words into lines of words,
 * with coordinates divided by `scale` so they're in PDF units (scale 1).
 */
export function linesFromResult(data, scale) {
  const lines = [];
  const r = (n) => Math.round((n / scale) * 100) / 100;
  for (const block of data.blocks ?? []) {
    for (const para of block.paragraphs ?? []) {
      for (const line of para.lines ?? []) {
        const words = line.words
          .filter((w) => w.text.trim())
          .map((w) => ({ t: w.text.trim(), x0: r(w.bbox.x0), y0: r(w.bbox.y0), x1: r(w.bbox.x1), y1: r(w.bbox.y1), c: w.confidence }));
        // Lines where every word is low-confidence are usually specks or pictures, not text.
        if (!words.length || words.every((w) => w.c < 25)) continue;
        lines.push({
          x0: r(line.bbox.x0),
          y0: r(line.bbox.y0),
          x1: r(line.bbox.x1),
          y1: r(line.bbox.y1),
          rtl: para.is_ltr === false,
          words: words.map(({ c, ...w }) => w),
        });
      }
    }
  }
  return lines;
}

let measureCtx;
function measure(text) {
  measureCtx ??= document.createElement('canvas').getContext('2d');
  measureCtx.font = '100px sans-serif';
  return measureCtx.measureText(text).width / 100;
}

/**
 * Builds transparent, selectable spans over the page image. Each word's span is
 * stretched to reach the start of the next word, so its trailing space is
 * selectable too and copying a line gives "word word word".
 * Positions use var(--scale-factor), so zooming needs no rebuild.
 */
export function renderOcrLayer(layer, lines) {
  const frag = document.createDocumentFragment();
  const px = (n) => `calc(var(--scale-factor) * ${n}px)`;
  for (const line of lines) {
    const height = Math.max(line.y1 - line.y0, 1);
    line.words.forEach((word, i) => {
      const next = line.words[i + 1];
      const text = next ? `${word.t} ` : word.t;
      let left = word.x0;
      let right = word.x1;
      if (next && line.rtl) left = Math.min(next.x1, word.x0);
      else if (next) right = Math.max(next.x0, word.x1);

      const span = document.createElement('span');
      span.textContent = text;
      if (line.rtl) span.dir = 'rtl';
      const natural = measure(text) * height || 1;
      span.style.left = px(left);
      span.style.top = px(line.y0);
      span.style.fontSize = px(height);
      span.style.transform = `scaleX(${((right - left) / natural).toFixed(4)})`;
      frag.append(span);
    });
    frag.append(document.createElement('br'));
  }
  const end = document.createElement('div');
  end.className = 'endOfContent';
  frag.append(end);
  layer.replaceChildren(frag);
}

// ---------------------------------------------------------------------------
// OCR results are cached per document fingerprint + page + language, so
// reopening a scanned PDF is instant.

const DB_NAME = 'pdf-translator';
const STORE = 'ocr';
let dbPromise;

function openDb() {
  dbPromise ??= new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function tx(mode, fn) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        const t = db.transaction(STORE, mode);
        const req = fn(t.objectStore(STORE));
        t.oncomplete = () => resolve(req?.result);
        t.onerror = () => reject(t.error);
      }),
  );
}

export const ocrCache = {
  get: (key) => tx('readonly', (s) => s.get(key)).catch(() => undefined),
  set: (key, lines) => tx('readwrite', (s) => s.put(lines, key)).catch(() => {}),
};
