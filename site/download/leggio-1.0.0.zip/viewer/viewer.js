import * as pdfjsLib from '../vendor/pdfjs/pdf.min.mjs';
import { Tooltip } from '../lib/tooltip.js';
import { OcrEngine, linesFromResult, renderOcrLayer, ocrCache } from './ocr.js';
import { translate, detectLanguage, translateInContext, sentenceAround, cleanSelection } from '../lib/translate.js';
import { loadSettings, saveSettings, onSettingsChanged, hotkeyLabel, loadApiKeys, onApiKeysChanged } from '../lib/settings.js';
import { TRANSLATE_LANGS, effectiveOcrLangs } from '../lib/languages.js';
import { getWords, saveWord, removeWord, restoreWord, findWord, onWordsChanged, toCsv, sourceUrl, sourceKey, kindOf, savedMessage, couldNotSave } from '../lib/words.js';
import { renderWordList, renderPager, showToast, matches } from '../lib/wordlist-view.js';

const PDFJS_DIR = new URL('../vendor/pdfjs/', import.meta.url).href;
pdfjsLib.GlobalWorkerOptions.workerSrc = `${PDFJS_DIR}pdf.worker.min.mjs`;

const MIN_NATIVE_CHARS = 12; // Pages with less extractable text than this are treated as scanned.
const MAX_CANVAS_PIXELS = 16_777_216;
const ZOOM_STEPS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5];
const MODIFIER_KEYS = ['Shift', 'Alt', 'Control', 'Meta'];
const SHORT_TEXT_WORDS = 12; // up to this many words, use the page's language instead of detecting the selection's
const inExtension = !!globalThis.chrome?.runtime?.id;

const $ = (id) => document.getElementById(id);
const container = $('viewerContainer');
const viewerEl = $('viewer');
const tooltip = new Tooltip(container);
const ocr = new OcrEngine();

let settings = await loadSettings();
// API keys for the optional DeepL / Google Cloud engines (kept on this computer only).
let apiKeys = await loadApiKeys();
onApiKeysChanged((keys) => (apiKeys = keys));

const state = {
  doc: null,
  loadingTask: null,
  generation: 0,
  url: null,
  fingerprint: '',
  views: [],
  scale: 1,
  zoom: 'page-width',
  currentPage: 1,
};

// ---------------------------------------------------------------- page view

class PageView {
  constructor(num, baseViewport) {
    this.num = num;
    this.base = { width: baseViewport.width, height: baseViewport.height };
    this.pagePromise = null;
    this.canvas = null;
    this.renderTask = null;
    this.renderedScale = 0;
    this.near = false;
    this.textState = 'none'; // none | loading | native | needs-ocr | ocr-queued | ocr-running | ocr | failed
    this.textLayer = null;
    this.sampleText = '';
    this.langPromise = null;

    this.div = document.createElement('div');
    this.div.className = 'page';
    this.div.dataset.page = num;
    this.canvasWrapper = document.createElement('div');
    this.canvasWrapper.className = 'canvasWrapper';
    this.textLayerDiv = document.createElement('div');
    this.textLayerDiv.className = 'textLayer';
    this.ocrLayerDiv = document.createElement('div');
    this.ocrLayerDiv.className = 'ocrLayer';
    this.badge = document.createElement('div');
    this.badge.className = 'page-badge';
    this.badge.hidden = true;
    this.div.append(this.canvasWrapper, this.textLayerDiv, this.ocrLayerDiv, this.badge);
    for (const layer of [this.textLayerDiv, this.ocrLayerDiv]) watchSelecting(layer);
  }

  getPage() {
    this.pagePromise ??= state.doc.getPage(this.num).then((page) => {
      const vp = page.getViewport({ scale: 1 });
      if (vp.width !== this.base.width || vp.height !== this.base.height) {
        this.base = { width: vp.width, height: vp.height };
        this.setScale(state.scale);
      }
      this.div.style.setProperty('--user-unit', page.userUnit ?? 1);
      return page;
    });
    return this.pagePromise;
  }

  setScale(scale) {
    this.div.style.width = `${Math.floor(this.base.width * scale)}px`;
    this.div.style.height = `${Math.floor(this.base.height * scale)}px`;
    this.div.style.setProperty('--scale-factor', scale);
    if (this.textLayer && this.pagePromise) {
      this.pagePromise.then((page) => this.textLayer?.update({ viewport: page.getViewport({ scale }) }));
    }
  }

  async render() {
    if (this.canvas && this.renderedScale === state.scale && this.renderedDpr === devicePixelRatio) return;
    this.renderTask?.cancel();
    const page = await this.getPage();
    const scale = state.scale;
    const viewport = page.getViewport({ scale });
    let outputScale = devicePixelRatio || 1;
    const pixels = viewport.width * viewport.height * outputScale ** 2;
    if (pixels > MAX_CANVAS_PIXELS) outputScale *= Math.sqrt(MAX_CANVAS_PIXELS / pixels);

    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width * outputScale);
    canvas.height = Math.floor(viewport.height * outputScale);
    const task = page.render({
      canvasContext: canvas.getContext('2d', { alpha: false }),
      viewport,
      transform: outputScale === 1 ? null : [outputScale, 0, 0, outputScale, 0, 0],
    });
    this.renderTask = task;
    try {
      await task.promise;
    } catch (err) {
      if (err?.name !== 'RenderingCancelledException') console.error(err);
      return;
    }
    if (this.renderTask !== task || !this.near) return;
    this.renderTask = null;
    // Swap only once the new canvas is ready, so zooming never flashes blank.
    this.canvasWrapper.replaceChildren(canvas);
    this.canvas = canvas;
    this.renderedScale = scale;
    this.renderedDpr = devicePixelRatio;
  }

  release() {
    this.renderTask?.cancel();
    this.renderTask = null;
    if (this.canvas) {
      this.canvas.width = this.canvas.height = 0;
      this.canvas.remove();
      this.canvas = null;
    }
  }

  async loadText() {
    if (this.textState !== 'none') return;
    this.textState = 'loading';
    const generation = state.generation;
    try {
      const page = await this.getPage();
      const content = await page.getTextContent();
      if (generation !== state.generation) return;
      const chars = content.items.reduce((n, item) => n + (item.str?.replace(/\s/g, '').length ?? 0), 0);
      this.sampleText = content.items.map((item) => item.str).join(' ');
      if (settings.sourceLang === 'auto') this.language().catch(() => {}); // warm up, so the first lookup doesn't wait for it

      if (chars >= MIN_NATIVE_CHARS) {
        this.textLayer = new pdfjsLib.TextLayer({
          textContentSource: content,
          container: this.textLayerDiv,
          viewport: page.getViewport({ scale: state.scale }),
        });
        await this.textLayer.render();
        const end = document.createElement('div');
        end.className = 'endOfContent';
        this.textLayerDiv.append(end);
        this.textState = 'native';
      } else {
        this.textState = 'needs-ocr';
        if (settings.ocrMode === 'auto') queueOcr(this);
        else this.showOcrPrompt();
      }
    } catch (err) {
      console.error(err);
      this.textState = 'failed';
    }
    updateOcrButton();
  }

  /** Language of the page's text, used as the source hint for short selections. */
  language() {
    this.langPromise ??= detectLanguage(this.sampleText);
    return this.langPromise;
  }

  showOcrPrompt() {
    this.badge.className = 'page-badge action';
    const label = document.createElement('span');
    label.textContent = 'No selectable text';
    const button = document.createElement('button');
    button.textContent = 'Run OCR';
    button.addEventListener('click', () => queueOcr(this, { force: true }));
    this.badge.replaceChildren(label, button);
    this.badge.hidden = false;
  }

  showProgress(label, progress) {
    this.badge.className = 'page-badge';
    const text = document.createElement('span');
    text.textContent = label;
    const meter = document.createElement('span');
    meter.className = 'meter';
    const fill = document.createElement('span');
    fill.style.width = `${Math.round((progress ?? 0) * 100)}%`;
    meter.append(fill);
    this.badge.replaceChildren(text, meter);
    this.badge.hidden = false;
  }

  hideBadge() {
    this.badge.hidden = true;
    this.badge.replaceChildren();
  }

  resetOcr() {
    ocrQueue.delete(this);
    this.ocrLayerDiv.replaceChildren();
    this.textLayerDiv.hidden = false;
    this.hideBadge();
    if (this.textState.startsWith('ocr') || this.textState === 'needs-ocr') {
      this.textState = this.textLayer ? 'native' : 'needs-ocr';
      this.langPromise = null;
      if (this.textState === 'needs-ocr' && this.near) {
        if (settings.ocrMode === 'auto') queueOcr(this);
        else this.showOcrPrompt();
      }
    }
  }
}

// Mirrors PDF.js: while dragging a selection, stretch an invisible block over the
// page so the selection doesn't jump around in the gaps between words.
function watchSelecting(layer) {
  layer.addEventListener('mousedown', () => layer.classList.add('selecting'));
}
document.addEventListener('mouseup', () => {
  for (const layer of viewerEl.querySelectorAll('.selecting')) layer.classList.remove('selecting');
});

// ------------------------------------------------------------------- OCR queue

const ocrQueue = new Set();
let ocrBusy = false;

function queueOcr(view, { force = false } = {}) {
  if (!force && view.textState !== 'needs-ocr') return;
  if (view.textState === 'ocr-running' || ocrQueue.has(view)) return;
  view.textState = 'ocr-queued';
  view.showProgress('Waiting for OCR', 0);
  ocrQueue.add(view);
  pumpOcr();
}

async function pumpOcr() {
  if (ocrBusy) return;
  ocrBusy = true;
  while (ocrQueue.size) {
    // Nearest page to where the reader is looking goes first.
    const next = [...ocrQueue].sort((a, b) => Math.abs(a.num - state.currentPage) - Math.abs(b.num - state.currentPage))[0];
    ocrQueue.delete(next);
    await runOcr(next);
  }
  ocrBusy = false;
  updateOcrStatus();
}

async function runOcr(view) {
  const generation = state.generation;
  const langs = [...effectiveOcrLangs(settings)];
  const key = `${state.fingerprint}|${view.num}|${langs.join('+')}`;
  view.textState = 'ocr-running';
  updateOcrStatus(view);
  view.showProgress('Reading text', 0);

  try {
    let lines = await ocrCache.get(key);
    if (!lines) {
      const page = await view.getPage();
      const base = page.getViewport({ scale: 1 });
      // ~300 DPI for a letter-sized page; Tesseract is most accurate around there.
      const ocrScale = Math.min(4, 3000 / Math.max(base.width, base.height));
      const viewport = page.getViewport({ scale: ocrScale });
      const canvas = document.createElement('canvas');
      canvas.width = Math.ceil(viewport.width);
      canvas.height = Math.ceil(viewport.height);
      await page.render({
        canvasContext: canvas.getContext('2d', { alpha: false }),
        viewport,
        annotationMode: pdfjsLib.AnnotationMode.DISABLE,
      }).promise;
      if (generation !== state.generation) return;

      const data = await ocr.recognize(canvas, langs, ({ label, progress }) => {
        if (generation !== state.generation) return;
        view.showProgress(label, progress);
        updateOcrStatus(view, label, progress);
      });
      canvas.width = canvas.height = 0;
      lines = linesFromResult(data, ocrScale);
      ocrCache.set(key, lines);
    }
    if (generation !== state.generation || view.textState !== 'ocr-running') return;

    renderOcrLayer(view.ocrLayerDiv, lines);
    view.textLayerDiv.hidden = true; // If OCR was forced over a native text layer, the OCR one wins.
    view.sampleText = lines.map((line) => line.words.map((w) => w.t).join(' ')).join('\n');
    view.langPromise = null;
    if (settings.sourceLang === 'auto') view.language().catch(() => {});
    view.textState = 'ocr';
    if (lines.length) {
      view.hideBadge();
    } else {
      view.badge.className = 'page-badge';
      view.badge.textContent = 'No text found on this page';
      view.badge.hidden = false;
      setTimeout(() => view.hideBadge(), 4000);
    }
  } catch (err) {
    console.error('[ocr]', err);
    if (generation !== state.generation) return;
    view.textState = 'failed';
    view.badge.className = 'page-badge';
    view.badge.textContent = `OCR failed: ${err?.message ?? err}`;
    view.badge.hidden = false;
  } finally {
    updateOcrButton();
  }
}

function updateOcrStatus(view, label, progress) {
  const status = $('ocrStatus');
  const pending = ocrQueue.size + (ocrBusy && view ? 1 : 0);
  if (!ocrBusy && !ocrQueue.size) {
    status.hidden = true;
    return;
  }
  const pct = progress != null ? ` · ${Math.round(progress * 100)}%` : '';
  const what = label && label !== 'Reading text' ? label : `OCR page ${view?.num ?? ''}`;
  status.textContent = `${what}${pct}${pending > 1 ? ` · ${pending - 1} queued` : ''}`;
  status.hidden = false;
}

function updateOcrButton() {
  const view = state.views[state.currentPage - 1];
  const button = $('ocrPage');
  button.disabled = !view || ['loading', 'ocr-queued', 'ocr-running'].includes(view.textState);
  button.querySelector('.label').textContent = view?.textState === 'ocr' ? 'Redo OCR' : 'OCR page';
}

// ------------------------------------------------------------ open documents

async function closeDocument() {
  state.generation++;
  tooltip.hide();
  observer.disconnect();
  ocrQueue.clear();
  for (const view of state.views) view.release();
  state.views = [];
  viewerEl.replaceChildren();
  const { doc, loadingTask } = state;
  state.doc = state.loadingTask = null;
  await (doc ?? loadingTask)?.destroy();
  updateOcrStatus();
}

async function openDocument(source, { name, url = null }) {
  await closeDocument();
  const generation = state.generation;
  state.url = url;
  showPanel(null);
  $('openOriginal').hidden = !(url && inExtension);
  setTitle(name);
  setProgress(0);

  const task = pdfjsLib.getDocument({
    ...source,
    cMapUrl: `${PDFJS_DIR}cmaps/`,
    cMapPacked: true,
    standardFontDataUrl: `${PDFJS_DIR}standard_fonts/`,
    wasmUrl: `${PDFJS_DIR}wasm/`,
    iccUrl: `${PDFJS_DIR}iccs/`,
  });
  state.loadingTask = task;
  task.onProgress = ({ loaded, total }) => setProgress(total ? loaded / total : null);
  task.onPassword = (updatePassword, reason) => {
    const retry = reason === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD;
    const password = prompt(retry ? 'Wrong password. Try again:' : 'This PDF is password-protected. Password:');
    if (password === null) task.destroy();
    else updatePassword(password);
  };

  let doc;
  try {
    doc = await task.promise;
  } catch (err) {
    if (generation !== state.generation) return;
    setProgress(false);
    return showError(describeLoadError(err));
  }
  if (generation !== state.generation) return doc.destroy();
  state.doc = doc;
  state.fingerprint = doc.fingerprints.filter(Boolean).join('-');
  setProgress(false);

  doc.getMetadata().then(({ info }) => {
    if (generation === state.generation && info?.Title?.trim()) document.title = info.Title.trim();
  }, () => {});

  const first = await doc.getPage(1);
  const base = first.getViewport({ scale: 1 });
  state.views = Array.from({ length: doc.numPages }, (_, i) => new PageView(i + 1, base));
  state.views[0].pagePromise = Promise.resolve(first);

  $('pageCount').textContent = `/ ${doc.numPages}`;
  updateMiniPage();
  $('pageNumber').value = 1;
  $('navGroup').hidden = false;
  state.currentPage = 1;
  applyZoom(state.zoom, { keepPosition: false });
  viewerEl.append(...state.views.map((v) => v.div));
  for (const view of state.views) observer.observe(view.div);

  const initialPage = Number(new URLSearchParams(location.hash.slice(1)).get('page'));
  if (initialPage > 1) scrollToPage(initialPage);
  container.focus({ preventScroll: true });
  updateOcrButton();
}

function describeLoadError(err) {
  if (err?.name === 'PasswordException') return 'The PDF is password-protected.';
  if (err?.name === 'InvalidPDFException') return "This file isn't a valid PDF.";
  if (err?.name === 'ResponseException' || err?.name === 'MissingPDFException') {
    return `The server responded with an error${err.status ? ` (HTTP ${err.status})` : ''}.`;
  }
  return err?.message || String(err);
}

async function openUrl(url) {
  const name = pdfjsLib.getPdfFilenameFromUrl(url, 'document.pdf');
  if (url.startsWith('file:')) {
    // fetch() doesn't support file: URLs; XHR does when "Allow access to file URLs" is on.
    try {
      const data = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.responseType = 'arraybuffer';
        xhr.onload = () => (xhr.response?.byteLength ? resolve(new Uint8Array(xhr.response)) : reject());
        xhr.onerror = reject;
        xhr.send();
      });
      return openDocument({ data }, { name, url });
    } catch {
      setTitle(name);
      return showError(
        'Chrome blocked access to local files. Open chrome://extensions, click Details on Leggio, and turn on "Allow access to file URLs". Or use the Open button.',
        { url },
      );
    }
  }
  return openDocument({ url, withCredentials: true }, { name, url });
}

async function openFile(file) {
  history.replaceState(null, '', location.pathname);
  const data = new Uint8Array(await file.arrayBuffer());
  return openDocument({ data }, { name: file.name });
}

function setTitle(name) {
  state.name = name || '';
  $('docTitle').textContent = name || '';
  $('docTitle').title = name || '';
  document.title = name ? `${name} · Leggio` : 'Leggio';
}

function setProgress(value) {
  const bar = $('progress');
  if (value === false) {
    bar.hidden = true;
    return;
  }
  bar.hidden = false;
  bar.classList.toggle('indeterminate', value == null);
  bar.firstElementChild.style.width = value == null ? '' : `${Math.round(value * 100)}%`;
}

function showPanel(id) {
  for (const panel of ['welcome', 'errorPanel']) $(panel).hidden = panel !== id;
}

function showError(message) {
  $('navGroup').hidden = true;
  $('errorMessage').textContent = message;
  $('errorOriginal').hidden = !(state.url && inExtension);
  showPanel('errorPanel');
}

// ------------------------------------------------------ rendering & scrolling

const observer = new IntersectionObserver(
  (entries) => {
    for (const entry of entries) {
      const view = state.views[Number(entry.target.dataset.page) - 1];
      if (!view) continue;
      view.near = entry.isIntersecting;
      if (view.near) {
        view.render();
        view.loadText();
      } else {
        view.release();
      }
    }
  },
  { root: container, rootMargin: '120% 0px' },
);

function computeScale(zoom) {
  const view = state.views[state.currentPage - 1] ?? state.views[0];
  if (!view) return 1;
  const availableWidth = container.clientWidth - 40;
  const availableHeight = container.clientHeight - 32;
  if (zoom === 'page-width') return clampScale(availableWidth / view.base.width);
  if (zoom === 'page-fit') return clampScale(Math.min(availableWidth / view.base.width, availableHeight / view.base.height));
  return clampScale(Number(zoom));
}

const clampScale = (s) => Math.min(Math.max(s, 0.25), 5);

function applyZoom(zoom, { keepPosition = true } = {}) {
  state.zoom = zoom;
  const scale = computeScale(zoom);
  const select = $('zoomSelect');
  const option = [...select.options].find((o) => o.value === String(zoom));
  if (option) {
    select.value = option.value;
  } else {
    select.options[select.options.length - 1].textContent = `${Math.round(scale * 100)}%`;
    select.value = 'custom';
  }
  if (!state.views.length) return;

  const anchor = state.views[state.currentPage - 1];
  const offset = keepPosition ? (container.scrollTop - anchor.div.offsetTop) / anchor.div.offsetHeight : 0;
  const changed = scale !== state.scale;
  state.scale = scale;
  for (const view of state.views) view.setScale(scale);
  if (keepPosition && changed) container.scrollTop = anchor.div.offsetTop + offset * anchor.div.offsetHeight;
  for (const view of state.views) if (view.near) view.render();
  if (changed) tooltip.hide();
}

function stepZoom(direction) {
  const current = state.scale;
  const next = direction > 0 ? ZOOM_STEPS.find((s) => s > current + 0.01) : ZOOM_STEPS.findLast((s) => s < current - 0.01);
  if (next) applyZoom(next);
}

function scrollToPage(num) {
  const view = state.views[Math.min(Math.max(num, 1), state.views.length) - 1];
  if (!view) return;
  container.scrollTop = view.div.offsetTop - 12;
  setCurrentPage(view.num);
}

function setCurrentPage(num) {
  if (num === state.currentPage) return;
  state.currentPage = num;
  updateMiniPage();
  if (document.activeElement !== $('pageNumber')) $('pageNumber').value = num;
  updateOcrButton();
}

let scrollFrame = 0;
container.addEventListener('scroll', () => {
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    const line = container.scrollTop + container.clientHeight * 0.35;
    const { views } = state;
    let lo = 0;
    let hi = views.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (views[mid].div.offsetTop <= line) lo = mid;
      else hi = mid - 1;
    }
    if (views[lo]) setCurrentPage(views[lo].num);
  });
});

let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => applyZoom(state.zoom), 150);
});

// ------------------------------------------------------------- translation

function viewFromNode(node) {
  const page = (node.nodeType === 1 ? node : node.parentElement)?.closest('.page');
  return page ? state.views[Number(page.dataset.page) - 1] : null;
}

/** Reads the current selection: the text to translate, its sentence, and where it is. */
function readSelection() {
  const selection = getSelection();
  if (!selection || selection.isCollapsed || !selection.rangeCount) return null;
  const range = selection.getRangeAt(0);
  if (tooltip.contains(range.commonAncestorContainer) || !container.contains(range.commonAncestorContainer)) return null;
  let text = cleanSelection(selection.toString());
  if (!text) return null;
  // Short selections get translated in the context of their sentence too.
  const context = text.split(' ').length <= 6 ? sentenceOfRange(range) : null;
  if (context && !text.includes(' ')) text = cleanSelection(context.word); // "attenzio-|ne" → "attenzione"
  const kind = kindOf(text, { lang: settings.sourceLang, context });
  return { text, context, kind, range, view: viewFromNode(range.startContainer) };
}

/**
 * Starts the word lookup and the sentence lookup together. Requests are cached
 * as promises, so calling this twice for the same selection (on double-click,
 * then on the hotkey) only sends them once.
 */
async function lookup({ text, context, view }, extra = {}) {
  const options = { target: settings.targetLang, provider: settings.provider, keys: apiKeys, source: settings.sourceLang || 'auto', ...extra };
  // With "Auto-detect", a word, a phrase or a short sentence is too little text to
  // detect reliably, so use the page's language (detected when the page loaded).
  if (options.source === 'auto' && view && text.split(' ').length <= SHORT_TEXT_WORDS) {
    options.source = (await view.language().catch(() => null)) || 'auto';
  }
  const word = translate(text, options);
  const meanings = word.then((r) => [r.translation, ...r.dict.flatMap((d) => d.terms)]).catch(() => []);
  const sentence = context ? translateInContext(context, { ...options, meanings }) : null;
  sentence?.catch(() => {});
  return { word, sentence };
}

async function translateSelection() {
  const selected = readSelection();
  if (!selected) return false;
  const rects = [...selected.range.getClientRects()].filter((r) => r.width > 0 && r.height > 0);
  const rect = rects.length === 1 ? rects[0] : selected.range.getBoundingClientRect();
  const token = tooltip.showLoading(rect, selected.text, selected.kind);

  const { word, sentence } = await lookup(selected, { onStatus: (status) => tooltip.setStatus(token, status) });
  try {
    const result = await word;
    let context = null;
    const saved = !!findWord(await getWords(), selected.text, result.source);
    tooltip.showResult(token, result, {
      onSpeak: speak,
      withContext: !!sentence,
      saved,
      saveKey: hotkeyLabel(settings.saveHotkey),
      // The star toggles: save the word, or remove it if it's already in the list.
      onSave: async () => {
        const existing = findWord(await getWords(), selected.text, result.source);
        if (existing) {
          await removeWord(existing.id);
          return false;
        }
        await saveWord(buildEntry(selected, result, context));
        return true;
      },
    });
    sentence
      ?.then((ctx) => {
        context = ctx;
        tooltip.showContext(token, ctx, result.translation);
      })
      .catch(() => tooltip.showContext(token, null));
  } catch (err) {
    tooltip.showError(token, err?.message || String(err));
  }
  return true;
}

/** The save key: looks the selection up (usually already cached) and adds it to the word list. */
async function saveSelection() {
  const selected = readSelection();
  if (!selected) return;
  const { word, sentence } = await lookup(selected);
  let result;
  try {
    result = await word;
  } catch (err) {
    showToast(couldNotSave(selected.text, err));
    return;
  }
  // Wait briefly for the meaning in context; save without it rather than keep the reader waiting.
  const context = sentence ? await Promise.race([sentence.catch(() => null), new Promise((r) => setTimeout(() => r(null), 3000))]) : null;
  const { entry, isNew } = await saveWord(buildEntry(selected, result, context));
  tooltip.setSaved(true);
  showToast(savedMessage(entry, isNew), {
    action: 'View list',
    onAction: openDrawer,
  });
}

function buildEntry(selected, result, context) {
  return {
    word: selected.text,
    kind: selected.kind,
    translation: context?.contextWord || result.translation,
    meanings: [...new Set(result.dict.flatMap((d) => d.terms))].slice(0, 8),
    before: context?.before ?? selected.context?.before ?? '',
    after: context?.after ?? selected.context?.after ?? '',
    sentenceTranslation: context?.translation ?? '',
    highlight: context?.highlight ?? null,
    source: result.source,
    target: result.target,
    doc: { title: state.name || document.title, url: state.url, page: selected.view?.num ?? null },
  };
}

// Double-clicking a word is how people pick one to look up, so start fetching
// right away; by the time the hotkey is pressed the answer is usually ready.
container.addEventListener('dblclick', (e) => {
  // Only for the free on-device engine: with a DeepL or Google Cloud key it would
  // spend the user's character quota on words they never look up.
  if (tooltip.contains(e.target) || settings.provider !== 'chrome') return;
  setTimeout(() => {
    const selected = readSelection();
    if (selected && selected.text.split(' ').length <= 3) lookup(selected).catch(() => {});
  }, 0);
});

/** The sentence around a selection in a page's text layer, split around the selection. */
function sentenceOfRange(range) {
  const element = (node) => (node.nodeType === Node.TEXT_NODE ? node.parentElement : node);
  const layer = element(range.startContainer)?.closest('.textLayer, .ocrLayer');
  if (!layer || !layer.contains(range.endContainer)) return null;
  if (range.startContainer.nodeType !== Node.TEXT_NODE || range.endContainer.nodeType !== Node.TEXT_NODE) return null;

  // Serialize the layer the way it reads: text nodes in order, <br> as a line break.
  let text = '';
  let start = -1;
  let end = -1;
  const walker = document.createTreeWalker(layer, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (node.nodeType === Node.TEXT_NODE) {
      if (node === range.startContainer) start = text.length + range.startOffset;
      if (node === range.endContainer) end = text.length + range.endOffset;
      text += node.data;
    } else if (node.nodeName === 'BR') {
      text += '\n';
    }
  }
  if (start < 0 || end <= start) return null;
  // Leave surrounding punctuation and spaces out of the marked word.
  while (start < end && /[\s\p{P}\p{S}]/u.test(text[start])) start++;
  while (end > start && /[\s\p{P}\p{S}]/u.test(text[end - 1])) end--;
  if (end <= start) return null;
  return sentenceAround(text, start, end);
}


function speak({ text, source }) {
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  if (source && source !== 'auto') utterance.lang = source === 'iw' ? 'he' : source;
  speechSynthesis.speak(utterance);
}

// ----------------------------------------------------------------- keyboard

// Two key bindings: `hotkey` translates the selection, `saveHotkey` saves it to the word list.
const BINDINGS = {
  hotkey: { verb: 'translate', run: () => translateSelection() },
  saveHotkey: { verb: 'save', run: () => saveSelection() },
};

// Clicking a key in the toolbar hint waits for the next key press and makes it that binding's key.
let capturing = null; // 'hotkey' | 'saveHotkey' | null
document.addEventListener(
  'keydown',
  (e) => {
    if (!capturing) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (['Tab', 'Enter', 'Dead', 'Unidentified'].includes(e.key)) return;
    if (e.key !== 'Escape') {
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      const other = capturing === 'hotkey' ? 'saveHotkey' : 'hotkey';
      if (settings[other] === key) {
        showToast(`${hotkeyLabel(key)} is already the key to ${BINDINGS[other].verb}. Pick another one.`);
        return;
      }
      settings = { ...settings, [capturing]: key };
      saveSettings({ [capturing]: key });
    }
    setCapture(null);
  },
  true,
);

const isEditable = (el) => el?.closest?.('input, textarea, select, [contenteditable=""], [contenteditable="true"]');
const normalizeKey = (key) => (key.length === 1 ? key.toLowerCase() : key);
let armed = null; // a binding whose modifier key is down with nothing else pressed yet
document.addEventListener(
  'keydown',
  (e) => {
    if (e.key === 'Escape') {
      if (tooltip.visible) {
        tooltip.hide();
        e.preventDefault();
      }
      closeMenu();
      closeDrawer();
      return;
    }
    // A modifier key binding fires on release, and only if nothing else was pressed with it.
    armed = !e.repeat ? (Object.keys(BINDINGS).find((name) => MODIFIER_KEYS.includes(settings[name]) && settings[name] === e.key) ?? null) : armed;
    if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.repeat && !isEditable(e.target) && !getSelection()?.isCollapsed) {
      const name = Object.keys(BINDINGS).find((n) => !MODIFIER_KEYS.includes(settings[n]) && normalizeKey(e.key) === settings[n]);
      if (name) {
        e.preventDefault();
        BINDINGS[name].run();
        return;
      }
    }

    // Ctrl/Cmd +, -, 0 zoom the document instead of the whole page.
    if ((e.ctrlKey || e.metaKey) && !e.altKey && state.views.length) {
      if (e.key === '=' || e.key === '+') stepZoom(1);
      else if (e.key === '-') stepZoom(-1);
      else if (e.key === '0') applyZoom('page-width');
      else return;
      e.preventDefault();
    }
  },
  true,
);
document.addEventListener(
  'keyup',
  (e) => {
    if (armed && e.key === settings[armed]) {
      const name = armed;
      armed = null;
      if (!isEditable(e.target)) BINDINGS[name].run();
    }
  },
  true,
);

// Shift-click extends selections; that shouldn't count as pressing a Shift hotkey.
document.addEventListener('mousedown', (e) => {
  armed = null;
  if (tooltip.visible && !tooltip.contains(e.target)) tooltip.hide();
}, true);

// ------------------------------------------------------------------ toolbar

function renderLanguageSelect() {
  const langs = [...TRANSLATE_LANGS].sort((a, b) => a[1].localeCompare(b[1]));
  const from = $('docLang');
  from.replaceChildren(new Option('Auto-detect', 'auto'), ...langs.map(([code, name]) => new Option(name, code)));
  from.value = settings.sourceLang || 'auto';
  const to = $('toLang');
  to.replaceChildren(...langs.map(([code, name]) => new Option(name, code)));
  to.value = settings.targetLang;
}

function renderHotkeyHint() {
  const hint = $('hotkeyHint');
  if (!hint.querySelector('.hotkey-button')) {
    // Built once and updated in place: replacing a focused button would blur it and cancel capture.
    const make = (name) => {
      const button = Object.assign(document.createElement('button'), { type: 'button', className: 'hotkey-button' });
      button.dataset.binding = name;
      button.append(document.createElement('kbd'));
      button.addEventListener('click', () => setCapture(capturing === name ? null : name));
      button.addEventListener('blur', () => capturing === name && setCapture(null));
      explain(button, () => {
        if (capturing === name) return ['Press the new key', 'Or press Esc to keep the current one.'];
        const k = hotkeyLabel(settings[name]);
        return name === 'hotkey'
          ? [`Translate: press ${k}`, `First select a word or phrase in the PDF (double-click a word, or drag across several), then press ${k} to see what it means in that sentence.`, 'Click to change this key.']
          : [`Save: press ${k}`, `First select a word, phrase or sentence in the PDF, then press ${k} to add it to your word list, with its meaning and where you found it.`, 'Click to change this key.'];
      });
      return button;
    };
    const label = (text) => Object.assign(document.createElement('span'), { className: 'hint-label', textContent: text });
    hint.replaceChildren(label(''), make('hotkey'), label('translate'), make('saveHotkey'), label('save'));
  }
  const [intro, translateButton, middle, saveButton, outro] = hint.children;
  intro.textContent = capturing ? `New key to ${BINDINGS[capturing].verb}:` : '';
  middle.hidden = outro.hidden = !!capturing;
  translateButton.hidden = capturing === 'saveHotkey';
  saveButton.hidden = capturing === 'hotkey';
  // Key buttons in the toolbar and in the welcome text.
  for (const button of document.querySelectorAll('.hotkey-button')) {
    const name = button.dataset.binding;
    const label = hotkeyLabel(settings[name]);
    const active = capturing === name;
    button.firstChild.textContent = active ? 'Press a key…' : label;
    button.classList.toggle('capturing', active);
    button.setAttribute('aria-label', active ? 'Press the new key, or Escape to cancel' : `Key to ${BINDINGS[name].verb}: ${label}. Click to change it.`);
  }
}

// Wires up a key button outside the toolbar hint (the one in the welcome text).
function bindKeyButton(button) {
  const name = button.dataset.binding;
  button.addEventListener('click', () => setCapture(capturing === name ? null : name, button));
  button.addEventListener('blur', () => capturing === name && setCapture(null));
}

function setCapture(name, button = name && $('hotkeyHint').querySelector(`[data-binding="${name}"]`)) {
  capturing = name;
  renderHotkeyHint();
  if (button) button.focus();
  else if (document.activeElement?.classList.contains('hotkey-button')) document.activeElement.blur();
}


function closeMenu() {
  $('menu').hidden = true;
  $('menuButton').setAttribute('aria-expanded', 'false');
}

$('docLang').addEventListener('change', (e) => saveSettings({ sourceLang: e.target.value }));
$('toLang').addEventListener('change', (e) => saveSettings({ targetLang: e.target.value }));
$('ocrPage').addEventListener('click', () => {
  const view = state.views[state.currentPage - 1];
  if (!view) return;
  view.ocrLayerDiv.replaceChildren();
  queueOcr(view, { force: true });
  updateOcrButton();
});

$('zoomSelect').addEventListener('change', (e) => {
  const { value } = e.target;
  if (value !== 'custom') applyZoom(value === 'page-width' || value === 'page-fit' ? value : Number(value));
});
$('zoomIn').addEventListener('click', () => stepZoom(1));
$('zoomOut').addEventListener('click', () => stepZoom(-1));

$('pageNumber').addEventListener('change', (e) => scrollToPage(Number(e.target.value) || 1));
$('pageNumber').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') e.target.blur();
});
$('pageNumber').addEventListener('blur', (e) => (e.target.value = state.currentPage));

const pickFile = () => $('fileInput').click();
$('openFile').addEventListener('click', pickFile);
$('welcomeOpen').addEventListener('click', pickFile);
for (const button of document.querySelectorAll('#welcome .hotkey-button')) bindKeyButton(button);
$('errorOpen').addEventListener('click', pickFile);
$('fileInput').addEventListener('change', (e) => {
  const [file] = e.target.files;
  if (file) openFile(file);
  e.target.value = '';
});

$('menuButton').addEventListener('click', () => {
  const menu = $('menu');
  menu.hidden = !menu.hidden;
  $('menuButton').setAttribute('aria-expanded', String(!menu.hidden));
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('.menu-wrap')) closeMenu();
});

async function openInChromeViewer() {
  if (!state.url) return;
  // Tell the background worker not to redirect this one navigation back here.
  if (inExtension) await chrome.runtime.sendMessage({ type: 'bypass', url: state.url }).catch(() => {});
  location.href = state.url;
}
$('openOriginal').addEventListener('click', openInChromeViewer);
$('errorOriginal').addEventListener('click', openInChromeViewer);
$('openSettings').addEventListener('click', () => {
  closeMenu();
  if (inExtension) chrome.runtime.openOptionsPage();
  else window.open('../options/options.html');
});

// Word list drawer
let drawerQuery = '';
let savedWords = [];
// The drawer shows this PDF's words or all of them, a page of 20 at a time.
const DRAWER_PAGE = 20;
let drawerScope = null; // 'this' | 'all', chosen on first open
let drawerPage = 1;

// Matches the doc a word is saved with (buildEntry), so sourceKey() finds this PDF's words.
const thisSource = () => (state.doc ? state.url || `title:${state.name || document.title}` : null);

function renderDrawer() {
  $('wordsCount').textContent = savedWords.length || '';
  if ($('wordsDrawer').hidden) return;
  const key = thisSource();
  const here = key ? savedWords.filter((w) => sourceKey(w) === key) : [];
  const scope = drawerScope === 'this' && key ? 'this' : 'all';
  $('scopeThis').hidden = !key;
  $('scopeThisCount').textContent = here.length;
  $('scopeAllCount').textContent = savedWords.length;
  $('scopeThis').setAttribute('aria-pressed', String(scope === 'this'));
  $('scopeAll').setAttribute('aria-pressed', String(scope === 'all'));

  const list = scope === 'this' ? here : savedWords;
  const total = list.filter((w) => matches(w, drawerQuery)).length;
  drawerPage = Math.min(drawerPage, Math.max(1, Math.ceil(total / DRAWER_PAGE)));
  const saveKey = hotkeyLabel(settings.saveHotkey);
  renderWordList($('drawerList'), list, {
    query: drawerQuery,
    page: drawerPage,
    pageSize: DRAWER_PAGE,
    showSource: scope === 'all',
    empty: scope === 'this' ? `No words from this PDF yet. Select one and press ${saveKey} to save it here.` : `Select a word and press ${saveKey} to save it here.`,
    onOpen: openSavedWord,
    onDelete: async (entry) => {
      await removeWord(entry.id);
      showToast(`Deleted "${entry.word}"`, { action: 'Undo', onAction: () => restoreWord(entry) });
    },
  });
  renderPager($('drawerPager'), {
    page: drawerPage,
    pageSize: DRAWER_PAGE,
    total,
    onPage: (to) => {
      drawerPage = to;
      renderDrawer();
      $('drawerList').scrollTop = 0;
    },
  });
}

function setDrawerScope(scope) {
  drawerScope = scope;
  drawerPage = 1;
  renderDrawer();
}

function openDrawer() {
  // First time: this PDF's words if it has any, otherwise everything
  if (!drawerScope) {
    const key = thisSource();
    drawerScope = key && savedWords.some((w) => sourceKey(w) === key) ? 'this' : 'all';
  }
  $('wordsDrawer').hidden = false;
  $('wordsButton').setAttribute('aria-expanded', 'true');
  renderDrawer();
  $('drawerSearch').focus();
}

function closeDrawer() {
  if ($('wordsDrawer').hidden) return;
  $('wordsDrawer').hidden = true;
  $('wordsButton').setAttribute('aria-expanded', 'false');
}

function openSavedWord(entry) {
  if (entry.doc?.url && entry.doc.url === state.url) {
    if (entry.doc.page) scrollToPage(entry.doc.page);
    closeDrawer();
  } else if (entry.doc?.url) {
    window.open(sourceUrl(entry), '_blank');
  }
}

const wordListUrl = new URL('../wordlist/wordlist.html', import.meta.url).href;
$('wordsButton').addEventListener('click', () => ($('wordsDrawer').hidden ? openDrawer() : closeDrawer()));
$('drawerClose').addEventListener('click', closeDrawer);
$('scopeThis').addEventListener('click', () => setDrawerScope('this'));
$('scopeAll').addEventListener('click', () => setDrawerScope('all'));
$('drawerSearch').addEventListener('input', (e) => {
  drawerQuery = e.target.value.trim();
  drawerPage = 1;
  renderDrawer();
});
// Opens the full list at this PDF's words when that's what the drawer shows
$('drawerFullList').addEventListener('click', () => {
  const key = drawerScope === 'this' && thisSource();
  window.open(key ? `${wordListUrl}#source=${encodeURIComponent(key)}` : wordListUrl, '_blank');
});
$('openWordList').addEventListener('click', () => {
  closeMenu();
  window.open(wordListUrl, '_blank');
});
$('drawerExport').addEventListener('click', () => {
  const key = drawerScope === 'this' && thisSource();
  downloadCsv(key ? savedWords.filter((w) => sourceKey(w) === key) : savedWords);
});

function downloadCsv(words) {
  const blob = new Blob(['\ufeff' + toCsv(words)], { type: 'text/csv;charset=utf-8' });
  const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: `leggio-words-${new Date().toISOString().slice(0, 10)}.csv` });
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

onWordsChanged((words) => {
  savedWords = words;
  renderDrawer();
});
getWords().then((words) => {
  savedWords = words;
  renderDrawer();
});

// Explanatory hover tooltips for toolbar controls. They appear quickly (unlike the
// browser's native ones) and can say more, e.g. that you select a word first.
const uiTip = Object.assign(document.createElement('div'), { className: 'ui-tip', id: 'uiTip', role: 'tooltip', hidden: true });
document.body.append(uiTip);
let tipTimer = 0;
let tipOwner = null;

function explain(element, text) {
  element.addEventListener('mouseenter', () => scheduleTip(element, text));
  element.addEventListener('focus', () => element.matches(':focus-visible') && scheduleTip(element, text));
  for (const type of ['mouseleave', 'blur', 'click']) element.addEventListener(type, hideTip);
}

function scheduleTip(element, text) {
  clearTimeout(tipTimer);
  tipTimer = setTimeout(() => showTip(element, typeof text === 'function' ? text() : text), 350);
}

function showTip(element, content) {
  if (!content || !element.isConnected || element.closest('[hidden]')) return;
  const [title, ...lines] = [].concat(content);
  uiTip.replaceChildren(Object.assign(document.createElement('strong'), { textContent: title }), ...lines.map((line) => Object.assign(document.createElement('span'), { textContent: line })));
  uiTip.hidden = false;
  tipOwner = element;
  element.setAttribute('aria-describedby', 'uiTip');
  const r = element.getBoundingClientRect();
  const { width, height } = uiTip.getBoundingClientRect();
  const below = r.bottom + 8 + height < innerHeight;
  uiTip.style.top = `${Math.round(below ? r.bottom + 8 : r.top - 8 - height)}px`;
  uiTip.style.left = `${Math.round(Math.min(Math.max(r.left + r.width / 2 - width / 2, 8), innerWidth - width - 8))}px`;
}

function hideTip() {
  clearTimeout(tipTimer);
  uiTip.hidden = true;
  tipOwner?.removeAttribute('aria-describedby');
  tipOwner = null;
}

const key = (name) => hotkeyLabel(settings[name]);
explain($('collapseToolbar'), ['Hide toolbar', 'Gives the page the full window. A small page-number button stays in the top-right corner; click it to bring the toolbar back.']);
explain($('expandToolbar'), () => ['Show toolbar', `You're on page ${state.currentPage} of ${state.views.length || 1}. Click to bring back the toolbar with zoom, languages and your word list.`]);
explain($('wordsButton'), () => ['Your word list', `Words you've saved (select a word, then press ${key('saveHotkey')}). Search them, jump back to where you found them, delete or export.`]);
document.addEventListener('scroll', hideTip, true);

// Collapsible toolbar, remembered per browser.
const TOOLBAR_KEY = 'pdf-translator-toolbar-collapsed';

function updateMiniPage() {
  $('miniPage').textContent = state.views.length ? `${state.currentPage} / ${state.views.length}` : '';
}

function setToolbarCollapsed(collapsed) {
  document.body.classList.toggle('toolbar-collapsed', collapsed);
  $('expandToolbar').hidden = !collapsed;
  closeMenu();
  updateMiniPage();
  try {
    localStorage.setItem(TOOLBAR_KEY, collapsed ? '1' : '0');
  } catch {}
  if (state.views.length) applyZoom(state.zoom); // "Fit page" depends on the height available
}

$('collapseToolbar').addEventListener('click', () => setToolbarCollapsed(true));
$('expandToolbar').addEventListener('click', () => setToolbarCollapsed(false));
try {
  if (localStorage.getItem(TOOLBAR_KEY) === '1') setToolbarCollapsed(true);
} catch {}

// Drag & drop
let dragDepth = 0;
const hasFiles = (e) => [...(e.dataTransfer?.types ?? [])].includes('Files');
window.addEventListener('dragenter', (e) => {
  if (!hasFiles(e)) return;
  dragDepth++;
  $('dropOverlay').hidden = false;
});
window.addEventListener('dragleave', () => {
  if (--dragDepth <= 0) {
    dragDepth = 0;
    $('dropOverlay').hidden = true;
  }
});
window.addEventListener('dragover', (e) => {
  if (hasFiles(e)) e.preventDefault();
});
window.addEventListener('drop', (e) => {
  e.preventDefault();
  dragDepth = 0;
  $('dropOverlay').hidden = true;
  const file = [...(e.dataTransfer?.files ?? [])].find((f) => f.type === 'application/pdf' || /\.pdf$/i.test(f.name));
  if (file) openFile(file);
});

// ---------------------------------------------------------------- settings

onSettingsChanged((patch) => {
  const ocrBefore = effectiveOcrLangs(settings).join('+');
  const modeChanged = patch.ocrMode && patch.ocrMode !== settings.ocrMode;
  settings = { ...settings, ...patch };
  const ocrChanged = effectiveOcrLangs(settings).join('+') !== ocrBefore;
  renderLanguageSelect();
  renderHotkeyHint();
  if (ocrChanged || modeChanged) for (const view of state.views) view.resetOcr();
});

// -------------------------------------------------------------------- start

renderLanguageSelect();
renderHotkeyHint();

const fileParam = new URLSearchParams(location.search).get('file');
if (fileParam) {
  const url = new URL(fileParam, location.href).href;
  openUrl(url);
} else {
  showPanel('welcome');
}

// Handy for debugging from the console.
globalThis.pdfTranslator = { state, settings: () => settings, translateSelection };
