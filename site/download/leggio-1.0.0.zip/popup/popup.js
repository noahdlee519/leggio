import { translate, translateInContext } from '../lib/translate.js';
import { loadSettings, saveSettings, loadApiKeys } from '../lib/settings.js';
import { TRANSLATE_LANGS, languageName } from '../lib/languages.js';
import { withBold } from '../lib/sentence-view.js';
import { getWords, saveWord, removeWord, findWord, onWordsChanged, kindOf } from '../lib/words.js';

// Popup for Chrome's own PDF viewer, where extensions can't read the selection:
// it translates whatever was copied. Copy a single word to look it up, or copy a
// whole sentence and click any word in it to see what it means in that sentence.

const $ = (id) => document.getElementById(id);
const content = $('content');
const settings = await loadSettings();

// The "from" language is the same document-language setting the viewer uses:
// a single word is too short to detect reliably.
const source = $('source');
source.append(
  new Option('Detect language', 'auto'),
  ...[...TRANSLATE_LANGS].sort((a, b) => a[1].localeCompare(b[1])).map(([code, name]) => new Option(name, code)),
);
source.value = settings.sourceLang || 'auto';
const target = $('target');
target.append(...[...TRANSLATE_LANGS].sort((a, b) => a[1].localeCompare(b[1])).map(([code, name]) => new Option(name, code)));
target.value = settings.targetLang;
target.addEventListener('change', () => {
  settings.targetLang = target.value;
  saveSettings({ targetLang: target.value });
  run();
});

const el = (tag, className, text) => Object.assign(document.createElement(tag), { className: className ?? '', textContent: text ?? '' });
const stripPunctuation = (s) => s.replace(/^[\p{P}\p{S}]+|[\p{P}\p{S}]+$/gu, '');
const apiKeys = await loadApiKeys();
const options = () => ({ target: settings.targetLang, source: source.value, provider: settings.provider, keys: apiKeys, onStatus: (s) => content.append(el('p', 'muted', s)) });

function show(...nodes) {
  content.replaceChildren(...nodes);
}

function dictionary(result) {
  const dict = el('dl', 'dict');
  for (const { pos, terms } of result.dict) dict.append(el('dt', '', pos || '·'), el('dd', '', terms.join(', ')));
  return dict;
}

function setSpeak(text, lang) {
  $('speak').hidden = false;
  $('speak').onclick = () => {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    if (lang && lang !== 'auto') u.lang = lang === 'iw' ? 'he' : lang;
    speechSynthesis.speak(u);
  };
}

async function readClipboard() {
  try {
    return (await navigator.clipboard.readText())
      .replace(/(\p{L})-\s*\n\s*(\p{Ll})/gu, '$1$2') // words hyphenated across lines
      .replace(/\s+/g, ' ')
      .trim();
  } catch {
    return '';
  }
}

const text = await readClipboard();

// Save / unsave button for a looked-up word.
async function saveButton(entry) {
  const button = el('button', 'save-word', '');
  button.type = 'button';
  const icon = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const paint = (saved) => {
    button.innerHTML = saved ? icon('<path d="m5.5 12.5 4 4 9-9.5"/>') : icon('<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/>');
    button.append(saved ? 'Saved' : `Save ${entry.kind}`);
    button.classList.toggle('saved', saved);
    button.setAttribute('aria-pressed', String(saved));
  };
  paint(!!findWord(await getWords(), entry.word, entry.source));
  button.addEventListener('click', async () => {
    const existing = findWord(await getWords(), entry.word, entry.source);
    if (existing) await removeWord(existing.id);
    else await saveWord(entry);
    paint(!existing);
  });
  return button;
}

const wordsLink = $('wordsLink');
wordsLink.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('wordlist/wordlist.html') }));
const paintCount = (words) => (wordsLink.textContent = `Your words (${words.length})`);
getWords().then(paintCount);
onWordsChanged(paintCount);

async function run() {
  $('speak').hidden = true;
  if (!text) {
    show(
      el('p', 'empty-title', 'Nothing copied yet'),
      el('p', 'muted', 'Select text in the PDF, press ⌘C / Ctrl+C, then press the shortcut again.'),
    );
  } else if (!text.includes(' ')) {
    await showWord(stripPunctuation(text));
  } else {
    await showSentence(text);
  }
}

async function showWord(word) {
  show(el('p', 'original', word), el('div', 'loading'));
  try {
    const result = await translate(word, options());
    const nodes = [el('p', 'original', result.text)];
    if (result.translit) nodes.push(el('p', 'muted', result.translit));
    nodes.push(el('p', 'translation', result.translation || '—'));
    if (result.dict.length) nodes.push(dictionary(result));
    if (source.value === 'auto' && result.source) {
      nodes.push(el('p', 'muted small', `Detected ${languageName(result.source)}. Wrong? Pick the language above.`));
    }
    nodes.push(
      await saveButton({
        word: result.text,
        // Copied text without spaces is usually one word, but may be a sentence (Japanese, Chinese…).
        kind: kindOf(result.text, { lang: result.source }),
        translation: result.translation,
        meanings: [...new Set(result.dict.flatMap((d) => d.terms))].slice(0, 8),
        before: '',
        after: '',
        sentenceTranslation: '',
        highlight: null,
        source: result.source,
        target: result.target,
        doc: { title: "Chrome's PDF viewer", url: null, page: null },
      }),
    );
    nodes.push(el('p', 'tip', 'Tip: copy the whole sentence instead, then click the word to see what it means in that sentence.'));
    show(...nodes);
    setSpeak(result.text, result.source);
  } catch (err) {
    show(el('p', 'original', word), el('p', 'error', err?.message || String(err)));
  }
}

async function showSentence(sentence) {
  show(el('p', 'original', sentence), el('div', 'loading'));
  let result;
  try {
    result = await translate(sentence, options());
  } catch (err) {
    show(el('p', 'original', sentence), el('p', 'error', err?.message || String(err)));
    return;
  }
  setSpeak(sentence, result.source);
  const lookupSource = source.value === 'auto' ? result.source || 'auto' : source.value;

  // Each word is a button; clicking it looks the word up in this sentence.
  const words = el('p', 'words');
  for (const m of sentence.matchAll(/\S+/g)) {
    const word = stripPunctuation(m[0]);
    if (!word) {
      words.append(m[0], ' ');
      continue;
    }
    const lead = m[0].indexOf(word);
    const button = el('button', 'word', word);
    button.type = 'button';
    button.addEventListener('click', () => {
      for (const b of words.querySelectorAll('.word.active')) b.classList.remove('active');
      button.classList.add('active');
      const start = m.index + lead;
      explain({ before: sentence.slice(0, start), word, after: sentence.slice(start + word.length) }, lookupSource);
    });
    words.append(m[0].slice(0, lead), button, m[0].slice(lead + word.length), ' ');
  }

  const translation = el('p', 'sentence-translation', result.translation);
  const card = el('div', 'word-card');
  card.append(el('p', 'muted small', 'Click a word to see what it means in this sentence.'));
  show(words, translation, card);

  async function explain(parts, lang) {
    card.replaceChildren(el('p', 'original', parts.word), el('div', 'loading'));
    translation.replaceChildren(result.translation);
    try {
      const opts = { ...options(), source: lang };
      // Word and sentence lookups run together; the word's meanings are only needed if Google loses the tag.
      const alonePromise = translate(parts.word, opts);
      const meanings = alonePromise.then((r) => [r.translation, ...r.dict.flatMap((d) => d.terms)]).catch(() => []);
      const [alone, ctx] = await Promise.all([alonePromise, translateInContext(parts, { ...opts, meanings }).catch(() => null)]);
      if (ctx) translation.replaceChildren(withBold(ctx.translation, ctx.highlight));
      const nodes = [el('p', 'original', parts.word)];
      if (ctx?.contextWord) {
        nodes.push(el('p', 'translation', ctx.contextWord));
        if (ctx.contextWord.toLocaleLowerCase() !== alone.translation.toLocaleLowerCase()) {
          nodes.push(el('p', 'muted', `on its own: ${alone.translation}`));
        }
      } else {
        nodes.push(el('p', 'translation', alone.translation || '—'));
      }
      if (alone.dict.length) {
        if (ctx?.contextWord) nodes.push(el('p', 'label', 'Other meanings'));
        nodes.push(dictionary(alone));
      }
      nodes.push(
        await saveButton({
          word: parts.word,
          kind: 'word',
          translation: ctx?.contextWord || alone.translation,
          meanings: [...new Set(alone.dict.flatMap((d) => d.terms))].slice(0, 8),
          before: parts.before,
          after: parts.after,
          sentenceTranslation: ctx?.translation ?? result.translation,
          highlight: ctx?.highlight ?? null,
          source: alone.source || lang,
          target: settings.targetLang,
          doc: { title: "Chrome's PDF viewer", url: null, page: null },
        }),
      );
      card.replaceChildren(...nodes);
    } catch (err) {
      card.replaceChildren(el('p', 'original', parts.word), el('p', 'error', err?.message || String(err)));
    }
  }
}

source.addEventListener('change', () => {
  saveSettings({ sourceLang: source.value });
  run();
});

run();
