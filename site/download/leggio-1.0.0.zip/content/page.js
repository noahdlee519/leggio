// Leggio on web pages: select a word, press the translate key, and the gloss slip
// shows what it means in its sentence; press the save key to add it to the word
// list. Loaded by loader.js the first time a key is pressed on a page.
//
// Everything Leggio draws lives in a closed shadow root, so the page's styles
// can't reach it and its own can't leak out.

import { Tooltip } from '../lib/tooltip.js';
import { translate, translateInContext, detectLanguage, sentenceAround, cleanSelection, useCloudTransport } from '../lib/translate.js';
import { loadSettings, onSettingsChanged, hotkeyLabel } from '../lib/settings.js';
import { getWords, saveWord, removeWord, findWord, kindOf, savedMessage, couldNotSave } from '../lib/words.js';
import { showToast } from '../lib/wordlist-view.js';

let settings = await loadSettings();
onSettingsChanged((patch) => (settings = { ...settings, ...patch }));

// DeepL and Google Cloud lookups go through the background worker, which holds the key.
useCloudTransport(async (text, options) => {
  let reply;
  try {
    reply = await chrome.runtime.sendMessage({ type: 'cloud-translate', text, options });
  } catch {
    throw new Error('Leggio was updated. Reload this page to keep using it.');
  }
  if (reply?.error) throw new Error(reply.error);
  if (!reply?.result) throw new Error("Leggio couldn't reach its translator. Reload this page and try again.");
  return reply.result;
});

// ------------------------------------------------------------------ the layer

const host = document.createElement('leggio-reader');
host.style.cssText = 'all: initial; position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647;';
const shadow = host.attachShadow({ mode: 'closed' });

// The slip is measured against the window: the host is fixed at its top-left corner.
const viewport = {
  getBoundingClientRect: () => ({ left: 0, top: 0 }),
  scrollLeft: 0,
  scrollTop: 0,
  get clientWidth() {
    return document.documentElement.clientWidth || innerWidth;
  },
  get clientHeight() {
    return Math.min(document.documentElement.clientHeight || innerHeight, innerHeight);
  },
};
const tooltip = new Tooltip(viewport, shadow);

const STYLES = ['lib/theme.css', 'lib/slip.css', 'lib/wordlist.css', 'content/page.css'];
const ready = Promise.all(STYLES.map(async (path) => (await fetch(chrome.runtime.getURL(path))).text())).then((texts) => {
  loadFonts(texts[0]);
  // @font-face doesn't work inside a shadow root; the fonts are added to the page's font set instead.
  shadow.adoptedStyleSheets = texts.map((css) => {
    const sheet = new CSSStyleSheet();
    sheet.replaceSync(css.replace(/@font-face\s*\{[^}]*\}/g, ''));
    return sheet;
  });
});

// The bundled Alegreya fonts, under their own names so they can't clash with the page's.
function loadFonts(themeCss) {
  const base = chrome.runtime.getURL('lib/theme.css');
  for (const [, rule] of themeCss.matchAll(/@font-face\s*\{([^}]*)\}/g)) {
    const prop = (name) => rule.match(new RegExp(`${name}:\\s*([^;]+);`))?.[1].trim();
    const url = prop('src')?.match(/url\("([^"]+)"\)/)?.[1];
    const family = prop('font-family')?.replace(/"/g, '');
    if (!url || !family) continue;
    const face = new FontFace(`Leggio ${family}`, `url("${new URL(url, base)}")`, {
      weight: prop('font-weight') ?? 'normal',
      style: prop('font-style') ?? 'normal',
      unicodeRange: prop('unicode-range') ?? 'U+0-10FFFF',
      display: 'swap',
    });
    document.fonts.add(face);
  }
}

async function mount() {
  await ready;
  // Some pages rebuild their whole document; put the layer back if it was removed.
  if (!host.isConnected) document.documentElement.append(host);
}

const toast = (message, options = {}) => showToast(message, { ...options, root: shadow });

// ------------------------------------------------------------- the selection

const inLayer = (node) => node === host || host.contains(node);

/** The current selection: the text to translate, its sentence, and where it is. */
function readSelection() {
  const selection = getSelection();
  if (!selection || selection.isCollapsed || !selection.rangeCount) return null;
  const range = selection.getRangeAt(0).cloneRange();
  if (inLayer(range.commonAncestorContainer)) return null;
  const raw = selection.toString();
  let text = cleanSelection(raw);
  if (!text) return null;
  // Short selections get translated in the context of their sentence too.
  const block = blockOf(range.commonAncestorContainer);
  const context = text.split(' ').length <= 6 ? sentenceOfRange(range, block) : null;
  if (context && !text.includes(' ')) text = cleanSelection(context.word);
  // All of one paragraph: no line breaks inside, and (nearly) all of its text.
  const wholeParagraph = !/\n/.test(raw.trim()) && text.length >= 0.9 * cleanSelection(block?.innerText ?? '').length;
  const kind = kindOf(text, { lang: settings.sourceLang, context, wholeParagraph });
  return { text, context, kind, range, block };
}

/** The nearest ancestor that lays out as a block: the paragraph, list item, heading or cell. */
function blockOf(node) {
  for (let el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement; el && el !== document.documentElement; el = el.parentElement) {
    const display = getComputedStyle(el).display;
    if (!display.startsWith('inline') && display !== 'contents') return el;
  }
  return document.body;
}

const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'TEXTAREA', 'SELECT', 'svg']);

/** The sentence around a selection, read from its paragraph as it's displayed. */
function sentenceOfRange(range, block) {
  if (!block) return null;
  // Whitespace is collapsed the way the page shows it; <br> stays a line break.
  const squash = (s) => s.replace(/\s+/g, ' ');
  let text = '';
  let start = -1;
  let end = -1;
  const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, {
    acceptNode: (node) =>
      node.nodeType === Node.ELEMENT_NODE && (SKIP.has(node.nodeName) || (node.checkVisibility && !node.checkVisibility()))
        ? NodeFilter.FILTER_REJECT
        : NodeFilter.FILTER_ACCEPT,
  });
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (node.nodeName === 'BR') {
      text += '\n';
    } else if (node.nodeType === Node.TEXT_NODE) {
      if (range.intersectsNode(node)) {
        if (start < 0) start = text.length + (node === range.startContainer ? squash(node.data.slice(0, range.startOffset)).length : 0);
        end = text.length + (node === range.endContainer ? squash(node.data.slice(0, range.endOffset)).length : squash(node.data).length);
      }
      text += squash(node.data);
      if (end >= 0 && text.length > end + 400) break; // enough for the rest of the sentence
    }
  }
  if (start < 0 || end <= start) return null;
  // Leave surrounding punctuation and spaces out of the marked word.
  while (start < end && /[\s\p{P}\p{S}]/u.test(text[start])) start++;
  while (end > start && /[\s\p{P}\p{S}]/u.test(text[end - 1])) end--;
  if (end <= start) return null;
  return sentenceAround(text, start, end);
}

function rectOf(range) {
  const rects = [...range.getClientRects()].filter((r) => r.width > 0 && r.height > 0);
  return rects.length === 1 ? rects[0] : range.getBoundingClientRect();
}

// ----------------------------------------------------------------- language

// A word, a phrase or a short sentence is too little text to detect its language,
// so a lookup with "Auto-detect" uses the paragraph's language, or failing that the page's.
const languages = new WeakMap();

function languageOf(block) {
  if (!languages.has(block)) languages.set(block, detectBlockLanguage(block).catch(() => null));
  return languages.get(block);
}

async function detectBlockLanguage(block) {
  const paragraph = block?.innerText ?? '';
  if (paragraph.trim().length >= 40) {
    const lang = await detectLanguage(paragraph);
    if (lang) return lang;
  }
  const declared = (document.documentElement.lang || '').toLowerCase();
  if (declared) return declared.startsWith('zh') ? (/tw|hk|hant/.test(declared) ? 'zh-TW' : 'zh-CN') : declared.split('-')[0];
  return detectLanguage(document.body?.innerText.slice(0, 2000) ?? '');
}

// --------------------------------------------------------------- the lookups

async function lookup({ text, context, block }, extra = {}) {
  const options = { target: settings.targetLang, provider: settings.provider, source: settings.sourceLang || 'auto', ...extra };
  if (options.source === 'auto' && text.split(' ').length <= 12) options.source = (await languageOf(block)) || 'auto';
  const word = translate(text, options);
  const meanings = word.then((r) => [r.translation, ...r.dict.flatMap((d) => d.terms)]).catch(() => []);
  const sentence = context ? translateInContext(context, { ...options, meanings }) : null;
  sentence?.catch(() => {});
  return { word, sentence };
}

function buildEntry(selected, result, context) {
  return {
    word: selected.text,
    kind: selected.kind,
    translation: context?.contextWord || result.translation,
    meanings: [...new Set(result.dict.flatMap((d) => d.terms))].slice(0, 8),
    before: context?.before ?? selected.context?.before ?? '',
    after: context?.after ?? selected.context?.after ?? '',
    sentenceTranslation: context?.translation ?? '',
    highlight: context?.highlight ?? null,
    source: result.source,
    target: result.target,
    doc: { title: document.title.trim() || location.hostname, url: location.href.split('#')[0], page: null, web: true },
  };
}

let anchor = null; // the selected range the open slip points at

async function translateSelection() {
  const selected = readSelection();
  if (!selected) return;
  await mount();
  anchor = selected.range;
  const token = tooltip.showLoading(rectOf(selected.range), selected.text, selected.kind);
  const { word, sentence } = await lookup(selected, { onStatus: (status) => tooltip.setStatus(token, status) });
  try {
    const result = await word;
    let context = null;
    tooltip.showResult(token, result, {
      onSpeak: speak,
      withContext: !!sentence,
      saved: !!findWord(await getWords(), selected.text, result.source),
      saveKey: hotkeyLabel(settings.saveHotkey),
      // Toggles: save the word, or remove it if it's already in the list.
      onSave: async () => {
        const existing = findWord(await getWords(), selected.text, result.source);
        if (existing) {
          await removeWord(existing.id);
          return false;
        }
        await saveWord(buildEntry(selected, result, context));
        return true;
      },
    });
    sentence
      ?.then((ctx) => {
        context = ctx;
        tooltip.showContext(token, ctx, result.translation);
      })
      .catch(() => tooltip.showContext(token, null));
  } catch (err) {
    tooltip.showError(token, err?.message || String(err));
  }
}

async function saveSelection() {
  const selected = readSelection();
  if (!selected) return;
  await mount();
  const { word, sentence } = await lookup(selected);
  let result;
  try {
    result = await word;
  } catch (err) {
    toast(couldNotSave(selected.text, err));
    return;
  }
  // Wait briefly for the meaning in context; save without it rather than keep the reader waiting.
  const context = sentence ? await Promise.race([sentence.catch(() => null), new Promise((r) => setTimeout(() => r(null), 3000))]) : null;
  const { entry, isNew } = await saveWord(buildEntry(selected, result, context));
  tooltip.setSaved(true);
  toast(savedMessage(entry, isNew), {
    action: 'View list',
    onAction: () => chrome.runtime.sendMessage({ type: 'open-word-list' }).catch(() => {}),
  });
}

function speak({ text, source }) {
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  if (source && source !== 'auto') utterance.lang = source === 'iw' ? 'he' : source;
  speechSynthesis.speak(utterance);
}

// ------------------------------------------------------------------- events

const ACTIONS = { hotkey: translateSelection, saveHotkey: saveSelection };

/** Called by loader.js when a key binding is pressed with text selected. */
export function run(name) {
  ACTIONS[name]?.().catch((err) => console.warn('Leggio:', err));
}

function close() {
  tooltip.hide();
  anchor = null;
}

addEventListener(
  'keydown',
  (e) => {
    if (e.key !== 'Escape' || !tooltip.visible) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    close();
  },
  true,
);

addEventListener('mousedown', (e) => tooltip.visible && !e.composedPath().includes(host) && close(), true);

// Keep the slip beside its word while the page (or a panel inside it) scrolls.
let frame = 0;
const follow = () => {
  if (!tooltip.visible || !anchor || frame) return;
  frame = requestAnimationFrame(() => {
    frame = 0;
    if (anchor) tooltip.follow(rectOf(anchor));
  });
};
addEventListener('scroll', follow, { capture: true, passive: true });
addEventListener('resize', follow, { passive: true });
