// Leggio on web pages. This script runs on every page, so it stays small: it only
// listens for the translate and save keys. The rest (translation, the gloss slip,
// saving) is loaded from page.js the first time one of them is pressed with text
// selected.
(() => {
  const MODIFIER_KEYS = ['Shift', 'Alt', 'Control', 'Meta'];
  // The same defaults as lib/settings.js (a content script can't import modules directly).
  const DEFAULTS = { hotkey: 't', saveHotkey: 's', webPages: true };
  const settings = { ...DEFAULTS };
  chrome.storage.sync
    .get(Object.keys(DEFAULTS))
    .then((stored) => Object.assign(settings, stored))
    .catch(() => {});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    for (const key of Object.keys(DEFAULTS)) if (changes[key]) settings[key] = changes[key].newValue ?? DEFAULTS[key];
  });

  let app = null;
  const run = (name) => {
    app ??= import(chrome.runtime.getURL('content/page.js'));
    app.then((m) => m.run(name)).catch((err) => {
      app = null;
      // After Leggio is updated or reloaded, pages opened before it lose their connection to it.
      console.warn('Leggio:', err?.message || err, '(reload the page if Leggio was just updated)');
    });
  };

  const bindingFor = (test) => ['hotkey', 'saveHotkey'].find((name) => test(settings[name]));
  const normalizeKey = (key) => (key.length === 1 ? key.toLowerCase() : key);
  const isEditable = (el) => !!el && (el.isContentEditable || !!el.closest?.('input, textarea, select'));
  const hasSelection = () => {
    const selection = getSelection();
    return !!selection && !selection.isCollapsed && selection.toString().trim() !== '';
  };

  // A key binding like Shift fires on release, and only if nothing else was pressed with it.
  let armed = null;
  addEventListener(
    'keydown',
    (e) => {
      if (!settings.webPages) return;
      armed = e.repeat ? armed : (bindingFor((key) => MODIFIER_KEYS.includes(key) && key === e.key) ?? null);
      if (e.ctrlKey || e.metaKey || e.altKey || e.repeat || isEditable(e.target) || !hasSelection()) return;
      const name = bindingFor((key) => !MODIFIER_KEYS.includes(key) && normalizeKey(e.key) === key);
      if (!name) return;
      // The page doesn't see the key: it was meant for Leggio, not the site's own shortcuts.
      e.preventDefault();
      e.stopImmediatePropagation();
      run(name);
    },
    true,
  );
  addEventListener(
    'keyup',
    (e) => {
      if (!armed || e.key !== settings[armed]) return;
      const name = armed;
      armed = null;
      if (settings.webPages && !isEditable(e.target) && hasSelection()) run(name);
    },
    true,
  );
  // Shift-click extends selections; that shouldn't count as pressing a Shift key binding.
  addEventListener('mousedown', () => (armed = null), true);
})();
