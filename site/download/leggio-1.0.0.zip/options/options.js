import { loadSettings, saveSettings, hotkeyLabel, loadApiKeys, saveApiKeys } from '../lib/settings.js';
import { testApiKey } from '../lib/translate.js';
import { TRANSLATE_LANGS } from '../lib/languages.js';

const $ = (id) => document.getElementById(id);
let settings = await loadSettings();

let savedTimer;
async function save(patch) {
  settings = { ...settings, ...patch };
  await saveSettings(patch);
  $('saved').textContent = 'Saved';
  $('saved').classList.add('show');
  clearTimeout(savedTimer);
  savedTimer = setTimeout(() => $('saved').classList.remove('show'), 1400);
}

// Document (source) language
const sourceSelect = $('sourceLang');
sourceSelect.append(new Option('Auto-detect', 'auto'), ...[...TRANSLATE_LANGS].sort((a, b) => a[1].localeCompare(b[1])).map(([code, name]) => new Option(name, code)));
sourceSelect.value = settings.sourceLang;
sourceSelect.addEventListener('change', () => save({ sourceLang: sourceSelect.value }));

// Target language
const target = $('targetLang');
target.append(...[...TRANSLATE_LANGS].sort((a, b) => a[1].localeCompare(b[1])).map(([code, name]) => new Option(name, code)));
target.value = settings.targetLang;
target.addEventListener('change', () => save({ targetLang: target.value }));

// Key capture: one for translating, one for saving to the word list.
const VERBS = { hotkey: 'translate', saveHotkey: 'save' };
for (const name of Object.keys(VERBS)) {
  const button = $(name);
  const help = $(`${name}Help`);
  let capturing = false;
  const show = () => {
    button.textContent = hotkeyLabel(settings[name]);
    button.classList.remove('capturing');
    help.hidden = true;
    help.textContent = 'Press any key… (Esc to cancel)';
    capturing = false;
  };
  show();
  button.addEventListener('click', () => {
    capturing = true;
    button.textContent = 'Press a key';
    button.classList.add('capturing');
    help.hidden = false;
  });
  button.addEventListener('blur', show);
  button.addEventListener('keydown', (e) => {
    if (!capturing) return;
    e.preventDefault();
    if (e.key === 'Escape') return show();
    if (['Tab', 'Enter', 'Dead', 'Unidentified'].includes(e.key)) return;
    const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    const other = name === 'hotkey' ? 'saveHotkey' : 'hotkey';
    if (settings[other] === key) {
      help.textContent = `${hotkeyLabel(key)} is already the key to ${VERBS[other]}. Pick another one.`;
      return;
    }
    save({ [name]: key }).then(show);
  });
}

$('openWords').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('wordlist/wordlist.html') }));
async function showWordsSummary() {
  const { savedWords = [] } = await chrome.storage.local.get('savedWords');
  $('wordsSummary').textContent = savedWords.length
    ? `${savedWords.length} saved word${savedWords.length === 1 ? '' : 's'}.`
    : `No saved words yet. Select a word in a PDF or on a web page and press ${hotkeyLabel(settings.saveHotkey)} to save it.`;
}
showWordsSummary();
chrome.storage.onChanged.addListener(showWordsSummary);

// Radios
for (const name of ['provider', 'ocrMode']) {
  for (const radio of document.querySelectorAll(`input[name="${name}"]`)) {
    radio.checked = radio.value === settings[name];
    radio.addEventListener('change', () => {
      if (!radio.checked) return;
      save({ [name]: radio.value });
      if (name === 'provider') showKeyRows();
    });
  }
}
$('chromeTranslatorNote').hidden = 'Translator' in globalThis;

// API keys for DeepL / Google Cloud: shown under their engine when it's chosen.
const keys = await loadApiKeys();
const KEY_FIELD = { deepl: 'deeplKey', 'google-cloud': 'googleCloudKey' };
const KEY_NAME = { deepl: 'deepl', 'google-cloud': 'googleCloud' };

function showKeyRows() {
  for (const row of document.querySelectorAll('.key-row')) {
    row.hidden = row.dataset.provider !== settings.provider;
    const status = row.querySelector('.key-status');
    if (!row.hidden && !keys[KEY_NAME[row.dataset.provider]] && !status.textContent) {
      status.textContent = 'Paste your key to start using this engine.';
    }
  }
}

for (const [provider, fieldId] of Object.entries(KEY_FIELD)) {
  const field = $(fieldId);
  field.value = keys[KEY_NAME[provider]] ?? '';
  field.addEventListener('change', async () => {
    keys[KEY_NAME[provider]] = field.value.trim();
    await saveApiKeys({ [KEY_NAME[provider]]: field.value.trim() });
    const status = field.closest('.key-row').querySelector('.key-status');
    status.className = 'help key-status';
    status.textContent = field.value.trim() ? 'Key saved on this computer.' : 'Key removed.';
  });
}

for (const button of document.querySelectorAll('.check-key')) {
  button.addEventListener('click', async () => {
    const provider = button.dataset.provider;
    const key = $(KEY_FIELD[provider]).value.trim();
    const status = button.closest('.key-row').querySelector('.key-status');
    status.className = 'help key-status';
    if (!key) {
      status.textContent = 'Paste a key first.';
      return;
    }
    button.disabled = true;
    status.textContent = 'Checking…';
    try {
      const translation = await testApiKey(provider, key, settings.targetLang);
      status.classList.add('ok');
      status.textContent = `The key works: "Buongiorno a tutti" → "${translation}".`;
    } catch (err) {
      status.classList.add('bad');
      status.textContent = err?.message || String(err);
    } finally {
      button.disabled = false;
    }
  });
}
showKeyRows();

// Toggles
for (const name of ['webPages', 'autoOpen']) {
  $(name).checked = settings[name];
  $(name).addEventListener('change', (e) => save({ [name]: e.target.checked }));
}

// Local file access
async function showFileAccess() {
  const text = $('fileAccessText');
  if (!globalThis.chrome?.extension?.isAllowedFileSchemeAccess) {
    text.textContent = 'Only available when running as an extension.';
    return;
  }
  const allowed = await chrome.extension.isAllowedFileSchemeAccess();
  text.textContent = allowed
    ? 'PDFs on your computer (file:// links) open here too.'
    : 'To open PDFs on your computer by double-clicking them in Chrome, turn on "Allow access to file URLs" on the extension\'s details page. You can always use the Open button in the viewer instead.';
  $('fileAccessButton').hidden = allowed;
}
$('fileAccessButton').addEventListener('click', () => chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` }));
showFileAccess();
