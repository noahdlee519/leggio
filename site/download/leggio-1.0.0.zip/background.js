import { loadSettings, loadApiKeys } from './lib/settings.js';
import { translate } from './lib/translate.js';

// Chrome's built-in PDF viewer is off-limits to extensions (content scripts can't
// run in it or read its selection), so PDFs are opened in our own viewer instead.
//
// How a PDF gets detected:
//   1. webRequest sees a main-frame response with Content-Type: application/pdf.
//   2. webNavigation sees that navigation commit.
// Once both have arrived for a tab (Chrome doesn't guarantee which comes first),
// the tab is sent to the viewer. The commit tells us whether it was a back/forward
// navigation, so pressing Back from the viewer shows the original PDF instead of
// bouncing into the viewer again.

const VIEWER_URL = chrome.runtime.getURL('viewer/viewer.html');
const MATCH_WINDOW_MS = 10_000;

const pdfResponses = new Map(); // tabId → { url, time } of a PDF response (url without #fragment)
const commits = new Map(); // tabId → { url, forwardBack, time } of the last main-frame commit
const bypassOnce = new Set(); // `${tabId} ${url}`: let this navigation show in Chrome's own viewer

const stripHash = (url) => url.split('#')[0];

export function viewerUrl(pdfUrl) {
  const hashIndex = pdfUrl.indexOf('#');
  const hash = hashIndex >= 0 ? pdfUrl.slice(hashIndex) : '';
  return `${VIEWER_URL}?file=${encodeURIComponent(stripHash(pdfUrl))}${hash}`;
}

function header(details, name) {
  return details.responseHeaders?.find((h) => h.name.toLowerCase() === name)?.value ?? '';
}

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0 || details.method !== 'GET') return;
    if (!(details.statusCode >= 200 && details.statusCode < 300) && details.statusCode !== 304) return;
    const type = header(details, 'content-type').split(';')[0].trim().toLowerCase();
    const isPdf =
      type === 'application/pdf' ||
      (['application/octet-stream', 'binary/octet-stream'].includes(type) && /\.pdf$/i.test(new URL(details.url).pathname));
    if (!isPdf || /^\s*attachment/i.test(header(details, 'content-disposition'))) {
      pdfResponses.delete(details.tabId);
      return;
    }
    pdfResponses.set(details.tabId, { url: stripHash(details.url), time: Date.now() });
    matchPdfCommit(details.tabId);
  },
  { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] },
  ['responseHeaders'],
);

// Chrome's own PDF viewer. A full-page PDF loads this frame, and inside it a frame
// with the same URL as the tab. (A page that embeds a PDF also loads the viewer,
// but the inner frame then has the PDF's URL, not the page's.)
const CHROME_PDF_VIEWER = 'chrome-extension://mhjfbmdgcfjbbpaeojofohoefgiehjai/';
const viewerFrameSeen = new Set(); // tabIds where Chrome's PDF viewer loaded since the last navigation

chrome.webNavigation.onCommitted.addListener((details) => {
  const { tabId, url, frameId } = details;
  if (frameId !== 0) {
    // Backstop for when the webRequest event was missed (e.g. while this worker was
    // starting up) or a server sent an unusual Content-Type.
    if (url.startsWith(CHROME_PDF_VIEWER)) {
      viewerFrameSeen.add(tabId);
    } else if (viewerFrameSeen.has(tabId) && commits.has(tabId) && stripHash(commits.get(tabId).url) === stripHash(url)) {
      const commit = takeCommit(tabId);
      if (commit) onPdfCommitted(tabId, commit.url, commit.forwardBack);
    }
    return;
  }
  viewerFrameSeen.delete(tabId);
  const forwardBack = !!details.transitionQualifiers?.includes('forward_back');
  commits.set(tabId, { url, forwardBack, time: Date.now() });
  if (url.startsWith('file:') && /\.pdf$/i.test(new URL(url).pathname)) {
    // Local files don't go through webRequest.
    takeCommit(tabId);
    onPdfCommitted(tabId, url, forwardBack);
    return;
  }
  const response = pdfResponses.get(tabId);
  if (response && response.url === stripHash(url)) matchPdfCommit(tabId);
});

function takeCommit(tabId) {
  const commit = commits.get(tabId);
  commits.delete(tabId);
  pdfResponses.delete(tabId);
  return commit && Date.now() - commit.time < MATCH_WINDOW_MS ? commit : null;
}

function matchPdfCommit(tabId) {
  const response = pdfResponses.get(tabId);
  const commit = commits.get(tabId);
  if (!response || !commit || response.url !== stripHash(commit.url)) return;
  if (Math.abs(response.time - commit.time) > MATCH_WINDOW_MS) return;
  takeCommit(tabId);
  onPdfCommitted(tabId, commit.url, commit.forwardBack);
}

async function onPdfCommitted(tabId, url, forwardBack) {
  // Reading local files needs "Allow access to file URLs" on the extension's details page.
  if (url.startsWith('file:') && !(await chrome.extension.isAllowedFileSchemeAccess())) return;
  await chrome.storage.session.set({ [`pdf:${tabId}`]: stripHash(url) });
  if (bypassOnce.delete(`${tabId} ${stripHash(url)}`)) return;
  if (forwardBack) return;
  if (!(await loadSettings()).autoOpen) return;
  chrome.tabs.update(tabId, { url: viewerUrl(url) });
}

chrome.tabs.onRemoved.addListener((tabId) => {
  pdfResponses.delete(tabId);
  commits.delete(tabId);
  viewerFrameSeen.delete(tabId);
  chrome.storage.session.remove(`pdf:${tabId}`);
});

// Toolbar button: open the current tab's PDF in the viewer, or an empty viewer.
chrome.action.onClicked.addListener(async (tab) => {
  const key = `pdf:${tab.id}`;
  const knownPdf = (await chrome.storage.session.get(key))[key];
  const url = tab.url ?? '';
  if (url && (stripHash(url) === knownPdf || /^(https?|file):.*\.pdf(\?|#|$)/i.test(url))) {
    chrome.tabs.update(tab.id, { url: viewerUrl(url) });
  } else {
    chrome.tabs.create({ url: VIEWER_URL, index: tab.index + 1 });
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'open-link',
    title: 'Read with Leggio',
    contexts: ['link'],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'open-link' && info.linkUrl) {
    chrome.tabs.create({ url: viewerUrl(info.linkUrl), index: (tab?.index ?? -1) + 1 });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'bypass' && sender.tab?.id != null) {
    bypassOnce.add(`${sender.tab.id} ${stripHash(message.url)}`);
    sendResponse(true);
  }
  // Lookups on web pages with the DeepL or Google Cloud engine: the content script
  // can't reach those services itself (the page's cross-origin rules apply to it)
  // and never gets the user's key, so the request is made here, key added.
  if (message?.type === 'cloud-translate' && sender.id === chrome.runtime.id) {
    const { text, options } = message;
    if (!['deepl', 'google-cloud'].includes(options?.provider) || typeof text !== 'string') return;
    loadApiKeys()
      .then((keys) => translate(text, { ...options, keys }))
      .then(
        (result) => sendResponse({ result }),
        (err) => sendResponse({ error: err?.message || String(err) }),
      );
    return true; // the response is sent asynchronously
  }
  // "View list" in the toast on a web page (a page can't open extension pages itself).
  if (message?.type === 'open-word-list' && sender.id === chrome.runtime.id) {
    chrome.tabs.create({ url: chrome.runtime.getURL('wordlist/wordlist.html'), index: (sender.tab?.index ?? -1) + 1 });
  }
});

// Shortcut for Chrome's built-in PDF viewer, where extensions can't read the selection:
// the user copies text, presses the shortcut, and a popup translates the clipboard.
// The toolbar button normally has no popup (it opens the viewer), so the popup is
// attached just long enough to open it.
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'translate-clipboard') return;
  await chrome.action.setPopup({ popup: 'popup/popup.html' });
  try {
    await chrome.action.openPopup();
  } finally {
    await chrome.action.setPopup({ popup: '' });
  }
});
